import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/components/frequency/frequency_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'add_pill_widget.dart' show AddPillWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AddPillModel extends FlutterFlowModel<AddPillWidget> {
  ///  Local state fields for this component.

  bool apiSucceeded = false;

  ///  State fields for stateful widgets in this component.

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController1;
  String? Function(BuildContext, String?)? textController1Validator;
  // Stores action output result for [Backend Call - API (FDA)] action in Button widget.
  ApiCallResponse? apiResultisd;
  // State field(s) for Expandable widget.
  late ExpandableController expandableExpandableController;

  // State field(s) for brand_name widget.
  FocusNode? brandNameFocusNode;
  TextEditingController? brandNameTextController;
  String? Function(BuildContext, String?)? brandNameTextControllerValidator;
  // State field(s) for generic_name widget.
  FocusNode? genericNameFocusNode;
  TextEditingController? genericNameTextController;
  String? Function(BuildContext, String?)? genericNameTextControllerValidator;
  // State field(s) for manufacturer widget.
  FocusNode? manufacturerFocusNode;
  TextEditingController? manufacturerTextController;
  String? Function(BuildContext, String?)? manufacturerTextControllerValidator;
  // State field(s) for ndc widget.
  FocusNode? ndcFocusNode;
  TextEditingController? ndcTextController;
  String? Function(BuildContext, String?)? ndcTextControllerValidator;
  // State field(s) for substance widget.
  FocusNode? substanceFocusNode;
  TextEditingController? substanceTextController;
  String? Function(BuildContext, String?)? substanceTextControllerValidator;
  // State field(s) for type widget.
  FocusNode? typeFocusNode;
  TextEditingController? typeTextController;
  String? Function(BuildContext, String?)? typeTextControllerValidator;
  // Stores action output result for [Backend Call - API (Get Pill Index)] action in Button widget.
  ApiCallResponse? indexOutput;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  PillRecord? documentCreated;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController1?.dispose();

    expandableExpandableController.dispose();
    brandNameFocusNode?.dispose();
    brandNameTextController?.dispose();

    genericNameFocusNode?.dispose();
    genericNameTextController?.dispose();

    manufacturerFocusNode?.dispose();
    manufacturerTextController?.dispose();

    ndcFocusNode?.dispose();
    ndcTextController?.dispose();

    substanceFocusNode?.dispose();
    substanceTextController?.dispose();

    typeFocusNode?.dispose();
    typeTextController?.dispose();
  }
}
