import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/components/pill_information/pill_information_widget.dart';
import '/components/pill_status/pill_status_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'home_page_widget.dart' show HomePageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomePageModel extends FlutterFlowModel<HomePageWidget> {
  ///  State fields for stateful widgets in this page.

  // Models for pillStatus dynamic component.
  late FlutterFlowDynamicModels<PillStatusModel> pillStatusModels;
  // Stores action output result for [Backend Call - API (Gemini Med Description)] action in pillStatus widget.
  ApiCallResponse? descriptResult;

  @override
  void initState(BuildContext context) {
    pillStatusModels = FlutterFlowDynamicModels(() => PillStatusModel());
  }

  @override
  void dispose() {
    pillStatusModels.dispose();
  }
}
