import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DispenserRecord extends FirestoreRecord {
  DispenserRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "frequencyHours" field.
  int? _frequencyHours;
  int get frequencyHours => _frequencyHours ?? 0;
  bool hasFrequencyHours() => _frequencyHours != null;

  // "ipAddress" field.
  String? _ipAddress;
  String get ipAddress => _ipAddress ?? '';
  bool hasIpAddress() => _ipAddress != null;

  // "nextDispenseAt" field.
  int? _nextDispenseAt;
  int get nextDispenseAt => _nextDispenseAt ?? 0;
  bool hasNextDispenseAt() => _nextDispenseAt != null;

  // "pillId" field.
  DocumentReference? _pillId;
  DocumentReference? get pillId => _pillId;
  bool hasPillId() => _pillId != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _frequencyHours = castToType<int>(snapshotData['frequencyHours']);
    _ipAddress = snapshotData['ipAddress'] as String?;
    _nextDispenseAt = castToType<int>(snapshotData['nextDispenseAt']);
    _pillId = snapshotData['pillId'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('dispenser');

  static Stream<DispenserRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => DispenserRecord.fromSnapshot(s));

  static Future<DispenserRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => DispenserRecord.fromSnapshot(s));

  static DispenserRecord fromSnapshot(DocumentSnapshot snapshot) =>
      DispenserRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static DispenserRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      DispenserRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'DispenserRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is DispenserRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDispenserRecordData({
  String? name,
  int? frequencyHours,
  String? ipAddress,
  int? nextDispenseAt,
  DocumentReference? pillId,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'frequencyHours': frequencyHours,
      'ipAddress': ipAddress,
      'nextDispenseAt': nextDispenseAt,
      'pillId': pillId,
    }.withoutNulls,
  );

  return firestoreData;
}

class DispenserRecordDocumentEquality implements Equality<DispenserRecord> {
  const DispenserRecordDocumentEquality();

  @override
  bool equals(DispenserRecord? e1, DispenserRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.frequencyHours == e2?.frequencyHours &&
        e1?.ipAddress == e2?.ipAddress &&
        e1?.nextDispenseAt == e2?.nextDispenseAt &&
        e1?.pillId == e2?.pillId;
  }

  @override
  int hash(DispenserRecord? e) => const ListEquality().hash(
      [e?.name, e?.frequencyHours, e?.ipAddress, e?.nextDispenseAt, e?.pillId]);

  @override
  bool isValidKey(Object? o) => o is DispenserRecord;
}
