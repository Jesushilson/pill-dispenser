import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PillRecord extends FirestoreRecord {
  PillRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "brand_name" field.
  String? _brandName;
  String get brandName => _brandName ?? '';
  bool hasBrandName() => _brandName != null;

  // "generic_name" field.
  String? _genericName;
  String get genericName => _genericName ?? '';
  bool hasGenericName() => _genericName != null;

  // "manufacturer" field.
  String? _manufacturer;
  String get manufacturer => _manufacturer ?? '';
  bool hasManufacturer() => _manufacturer != null;

  // "ndc" field.
  String? _ndc;
  String get ndc => _ndc ?? '';
  bool hasNdc() => _ndc != null;

  // "substance" field.
  String? _substance;
  String get substance => _substance ?? '';
  bool hasSubstance() => _substance != null;

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  bool hasType() => _type != null;

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  // "dosage" field.
  int? _dosage;
  int get dosage => _dosage ?? 0;
  bool hasDosage() => _dosage != null;

  // "next_dispensed" field.
  int? _nextDispensed;
  int get nextDispensed => _nextDispensed ?? 0;
  bool hasNextDispensed() => _nextDispensed != null;

  // "last_dispensed" field.
  int? _lastDispensed;
  int get lastDispensed => _lastDispensed ?? 0;
  bool hasLastDispensed() => _lastDispensed != null;

  // "index" field.
  int? _index;
  int get index => _index ?? 0;
  bool hasIndex() => _index != null;

  void _initializeFields() {
    _brandName = snapshotData['brand_name'] as String?;
    _genericName = snapshotData['generic_name'] as String?;
    _manufacturer = snapshotData['manufacturer'] as String?;
    _ndc = snapshotData['ndc'] as String?;
    _substance = snapshotData['substance'] as String?;
    _type = snapshotData['type'] as String?;
    _user = snapshotData['user'] as DocumentReference?;
    _dosage = castToType<int>(snapshotData['dosage']);
    _nextDispensed = castToType<int>(snapshotData['next_dispensed']);
    _lastDispensed = castToType<int>(snapshotData['last_dispensed']);
    _index = castToType<int>(snapshotData['index']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('pill');

  static Stream<PillRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PillRecord.fromSnapshot(s));

  static Future<PillRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PillRecord.fromSnapshot(s));

  static PillRecord fromSnapshot(DocumentSnapshot snapshot) => PillRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PillRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PillRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PillRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PillRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPillRecordData({
  String? brandName,
  String? genericName,
  String? manufacturer,
  String? ndc,
  String? substance,
  String? type,
  DocumentReference? user,
  int? dosage,
  int? nextDispensed,
  int? lastDispensed,
  int? index,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'brand_name': brandName,
      'generic_name': genericName,
      'manufacturer': manufacturer,
      'ndc': ndc,
      'substance': substance,
      'type': type,
      'user': user,
      'dosage': dosage,
      'next_dispensed': nextDispensed,
      'last_dispensed': lastDispensed,
      'index': index,
    }.withoutNulls,
  );

  return firestoreData;
}

class PillRecordDocumentEquality implements Equality<PillRecord> {
  const PillRecordDocumentEquality();

  @override
  bool equals(PillRecord? e1, PillRecord? e2) {
    return e1?.brandName == e2?.brandName &&
        e1?.genericName == e2?.genericName &&
        e1?.manufacturer == e2?.manufacturer &&
        e1?.ndc == e2?.ndc &&
        e1?.substance == e2?.substance &&
        e1?.type == e2?.type &&
        e1?.user == e2?.user &&
        e1?.dosage == e2?.dosage &&
        e1?.nextDispensed == e2?.nextDispensed &&
        e1?.lastDispensed == e2?.lastDispensed &&
        e1?.index == e2?.index;
  }

  @override
  int hash(PillRecord? e) => const ListEquality().hash([
        e?.brandName,
        e?.genericName,
        e?.manufacturer,
        e?.ndc,
        e?.substance,
        e?.type,
        e?.user,
        e?.dosage,
        e?.nextDispensed,
        e?.lastDispensed,
        e?.index
      ]);

  @override
  bool isValidKey(Object? o) => o is PillRecord;
}
