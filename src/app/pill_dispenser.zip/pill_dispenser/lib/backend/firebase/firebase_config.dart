import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyA9j6maoO9gnBjaUyZ_2X2yyYJeVcOAwFo",
            authDomain: "pill-dispenser-a0346.firebaseapp.com",
            projectId: "pill-dispenser-a0346",
            storageBucket: "pill-dispenser-a0346.firebasestorage.app",
            messagingSenderId: "899012609711",
            appId: "1:899012609711:web:3b815e62187792d4f9765a",
            measurementId: "G-3GHNMPE6W0"));
  } else {
    await Firebase.initializeApp();
  }
}
