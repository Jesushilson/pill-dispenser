import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/auth/firebase_auth/auth_util.dart';

DateTime? newCustomFunction(
  DateTime time,
  int freq,
) {
  switch (freq) {
    case 1:
      {
        return time.add(Duration(hours: 24));
      }
    case 2:
      {
        return time.add(Duration(hours: 12));
      }
    case 3:
      {
        return time.add(Duration(hours: 8));
      }
    case 4:
      {
        return time.add(Duration(hours: 6));
      }
    case 6:
      {
        return time.add(Duration(hours: 4));
      }
  }
  return time.add(Duration(hours: 0));
}

DateTime? unixSecondsToDateTime(int seconds) {
  return DateTime.fromMillisecondsSinceEpoch(seconds * 1000);
}
